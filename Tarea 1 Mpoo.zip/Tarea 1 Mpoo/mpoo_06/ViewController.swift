//
//  ViewController.swift
//  Mpoo_06
//
//  Created by Salazar Olivares Ricardo
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    var alumnos:[Alumno] = [
        Alumno(nombre: "Laura", imagen: "uno"),
        Alumno(nombre: "Juan", imagen: "dos"),
        Alumno(nombre: "Paco fino", imagen: "tres")
    ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! CeldaTableViewCell
        
        //cell.textLabel?.text = alumno[indexPath.row]
        
        let nombre = alumnos[indexPath.row].nombre
        let imagen = alumnos[indexPath.row].imagen
        
        cell.nombre.text = nombre
        cell.imagen.image = UIImage(named: imagen)
        
        return cell
    }
}

