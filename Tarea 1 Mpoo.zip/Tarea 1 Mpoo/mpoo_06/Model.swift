//
//  Model.swift
//  Mpoo_06
//
//  Created by Salazar Olivares Ricardo
//

import Foundation

struct Alumno{
    var nombre:String
    var imagen:String
}
